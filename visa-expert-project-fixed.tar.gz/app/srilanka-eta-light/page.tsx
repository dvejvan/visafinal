import SriLankaEtaLandingPage from '@/components/srilanka-eta-landing-page'

export default function SriLankaEtaLightPage() {
  console.log('🇱🇰 Sri Lanka ETA Light page loaded')
  
  return <SriLankaEtaLandingPage />
}