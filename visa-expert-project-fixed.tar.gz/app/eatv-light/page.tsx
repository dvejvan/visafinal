'use client'

import EatvLandingPage from '@/components/eatv-landing-page'

console.log('🌍 EATV Light page rendered')

export default function EatvLightPage() {
  console.log('🌍 EATV Light Page component rendered')
  
  return <EatvLandingPage />
}